Unpack the sexpr_1.0.0 distribution in this directory.  The project file
expects ./sexpr_1.0.0/ to be here with the source distribution inside there.
If there are problems, ensure that the directories inside the project file
match the one for the distribution.  For example, if the version of the 
distribution increases, it is possible that this project file will need to be
updated.
